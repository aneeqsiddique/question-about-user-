"""
Intern interview question generator: RAG + structured prompt + validation.

Pipeline:
  JD + profile -> PII strip -> skill extraction -> retrieve similar bank
  questions -> LLM generation -> validation (schema, dedup, coverage,
  bias filter) -> retry with feedback -> JSON output for human review.

Usage:
  pip install -r requirements.txt
  export ANTHROPIC_API_KEY=...
  python generator.py --role "Data Analyst Intern" \
      --jd jd.txt --profile profile.txt --bank question_bank.sample.json \
      --out interview_set.json

  Add --dry-run to print the prompt without calling any model.
"""

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field
from typing import Callable

from sentence_transformers import SentenceTransformer, util

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

EMBED_MODEL = "all-MiniLM-L6-v2"
LLM_MODEL = os.environ.get("LLM_MODEL", "claude-sonnet-5-5")
DUP_THRESHOLD = 0.90      # cosine similarity above this = duplicate
MAX_RETRIES = 2
TOP_K_REFERENCES = 8

# Extend this vocabulary for your domain. Used for lightweight skill extraction.
SKILL_VOCAB = [
    "python", "sql", "pandas", "numpy", "excel", "tableau", "power bi",
    "machine learning", "statistics", "data cleaning", "visualization",
    "java", "javascript", "typescript", "react", "node", "html", "css",
    "git", "docker", "aws", "linux", "rest api", "testing", "algorithms",
    "data structures", "communication", "teamwork", "problem solving",
]

# Questions touching these topics are blocked (legal / fairness filter).
BANNED_PATTERNS = [
    r"\b(age|how old|birth ?date|date of birth)\b",
    r"\b(married|marital|pregnan\w*|children|kids|family plans?)\b",
    r"\b(religio\w*|church|mosque|temple|faith)\b",
    r"\b(ethnic\w*|race|racial|nationality|citizen\w*|accent|where are you from)\b",
    r"\b(gender|sexual orientation|disabilit\w*|health condition)\b",
]

# --------------------------------------------------------------------------
# Data structures
# --------------------------------------------------------------------------

@dataclass
class Context:
    role: str
    jd_text: str
    profile_text: str
    skills: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------
# Step 1-2: Ingest, anonymize, extract skills
# --------------------------------------------------------------------------

def strip_pii(text: str) -> str:
    """Remove obvious PII before text reaches the model."""
    text = re.sub(r"[\w.+-]+@[\w-]+\.[\w.-]+", "[EMAIL]", text)
    text = re.sub(r"(\+?\d[\d\s().-]{8,}\d)", "[PHONE]", text)
    text = re.sub(r"https?://\S+|www\.\S+", "[URL]", text)
    text = re.sub(r"(?im)^\s*(name|age|gender|dob|date of birth|address|nationality)\s*:.*$",
                  "", text)
    return text.strip()


def extract_skills(jd_text: str) -> list[str]:
    low = jd_text.lower()
    return sorted({s for s in SKILL_VOCAB
                   if re.search(rf"(?<!\w){re.escape(s)}(?!\w)", low)})


# --------------------------------------------------------------------------
# Step 3: Retrieval
# --------------------------------------------------------------------------

class QuestionBank:
    def __init__(self, path: str, embedder: SentenceTransformer):
        with open(path, encoding="utf-8") as f:
            self.items = json.load(f)
        self.embedder = embedder
        self.texts = [it["question"] for it in self.items]
        self.emb = embedder.encode(self.texts, convert_to_tensor=True,
                                   normalize_embeddings=True)

    def retrieve(self, query: str, k: int = TOP_K_REFERENCES) -> list[dict]:
        q = self.embedder.encode(query, convert_to_tensor=True,
                                 normalize_embeddings=True)
        hits = util.semantic_search(q, self.emb, top_k=min(k, len(self.items)))[0]
        return [self.items[h["corpus_id"]] for h in hits]


# --------------------------------------------------------------------------
# Step 4: Prompt + generation
# --------------------------------------------------------------------------

PROMPT_TEMPLATE = """You are a technical recruiter creating interview questions for an intern.

ROLE: {role}
REQUIRED SKILLS: {skills}
CANDIDATE BACKGROUND (anonymized):
{profile}

DIFFICULTY: Entry-level. Interns may lack professional experience, so allow
school, personal, and volunteer examples.

REFERENCE QUESTIONS (match style and difficulty, do NOT copy):
{references}

Generate:
- 5 technical questions (2 easy, 2 medium, 1 stretch), each tied to one
  required skill, with a 2-3 line "what a good answer covers" rubric
- 4 behavioral questions (STAR-style), each with a rubric
- 2 project-based questions about the candidate's own listed projects

Rules: no trick questions, no questions about personal characteristics, no
duplicates of the references. Every required skill must be covered by at
least one question. Difficulty must be one of: easy, medium, stretch.

Return ONLY valid JSON, no markdown fences, in this shape:
{{"technical":[{{"question":"","skill":"","difficulty":"","rubric":""}}],
 "behavioral":[{{"question":"","skill":"","difficulty":"","rubric":""}}],
 "project_based":[{{"question":"","skill":"","difficulty":"","rubric":""}}]}}
{feedback}"""


def build_prompt(ctx: Context, refs: list[dict], feedback: str = "") -> str:
    ref_lines = "\n".join(
        f"- [{r.get('type','?')}/{r.get('difficulty','?')}] {r['question']}" for r in refs)
    fb = f"\nFIX THESE ISSUES FROM YOUR PREVIOUS ATTEMPT:\n{feedback}\n" if feedback else ""
    return PROMPT_TEMPLATE.format(
        role=ctx.role,
        skills=", ".join(ctx.skills) or "(infer from role)",
        profile=ctx.profile_text or "(not provided)",
        references=ref_lines or "(none)",
        feedback=fb,
    )


# An LLM backend is any function: prompt (str) -> response text (str).
LLMFn = Callable[[str], str]


def anthropic_llm(prompt: str) -> str:
    import anthropic  # pip install anthropic
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY
    msg = client.messages.create(
        model=LLM_MODEL,
        max_tokens=3000,
        temperature=0.7,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(b.text for b in msg.content if b.type == "text")


def local_llama_llm(prompt: str) -> str:
    """Example for a local LLaMA via Hugging Face transformers (swap in as needed)."""
    from transformers import pipeline
    gen = local_llama_llm._pipe = getattr(local_llama_llm, "_pipe", None) or pipeline(
        "text-generation", model=os.environ["LOCAL_MODEL"], device_map="auto")
    out = gen(prompt, max_new_tokens=2000, do_sample=True, temperature=0.7,
              return_full_text=False)
    return out[0]["generated_text"]


def parse_json(raw: str) -> dict:
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("No JSON object found in model output")
    return json.loads(raw[start:end + 1])


# --------------------------------------------------------------------------
# Step 5: Validation
# --------------------------------------------------------------------------

REQUIRED_KEYS = {"question", "skill", "difficulty", "rubric"}
EXPECTED_COUNTS = {"technical": 5, "behavioral": 4, "project_based": 2}
VALID_DIFFICULTY = {"easy", "medium", "stretch"}


def validate(result: dict, ctx: Context, bank: QuestionBank,
             embedder: SentenceTransformer) -> list[str]:
    issues: list[str] = []

    # Schema and counts
    flat: list[tuple[str, dict]] = []
    for section, expected in EXPECTED_COUNTS.items():
        items = result.get(section)
        if not isinstance(items, list):
            issues.append(f"Missing section '{section}'.")
            continue
        if len(items) != expected:
            issues.append(f"'{section}' has {len(items)} questions, expected {expected}.")
        for i, q in enumerate(items):
            missing = REQUIRED_KEYS - set(q)
            if missing:
                issues.append(f"{section}[{i}] missing keys: {sorted(missing)}.")
                continue
            if str(q["difficulty"]).lower() not in VALID_DIFFICULTY:
                issues.append(f"{section}[{i}] has invalid difficulty '{q['difficulty']}'.")
            flat.append((section, q))
    if not flat:
        return issues

    # Bias / legality filter
    for section, q in flat:
        for pat in BANNED_PATTERNS:
            if re.search(pat, q["question"], flags=re.IGNORECASE):
                issues.append(f"Question touches a protected topic: \"{q['question']}\"")
                break

    # Duplicate check vs bank and within the generated set
    texts = [q["question"] for _, q in flat]
    emb = embedder.encode(texts, convert_to_tensor=True, normalize_embeddings=True)
    vs_bank = util.cos_sim(emb, bank.emb)
    for i, t in enumerate(texts):
        if float(vs_bank[i].max()) > DUP_THRESHOLD:
            issues.append(f"Too similar to a bank question: \"{t}\"")
    within = util.cos_sim(emb, emb)
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            if float(within[i][j]) > DUP_THRESHOLD:
                issues.append(f"Near-duplicate pair: \"{texts[i]}\" / \"{texts[j]}\"")

    # JD skill coverage
    covered = " ".join((q["skill"] + " " + q["question"]).lower() for _, q in flat)
    uncovered = [s for s in ctx.skills if s not in covered]
    if uncovered:
        issues.append(f"These required skills are not covered: {uncovered}.")

    return issues


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def generate_interview_set(ctx: Context, bank: QuestionBank,
                           embedder: SentenceTransformer, llm: LLMFn) -> dict:
    query = f"{ctx.role}. Skills: {', '.join(ctx.skills)}. {ctx.profile_text[:500]}"
    refs = bank.retrieve(query)

    feedback = ""
    result, issues = {}, ["not generated"]
    for attempt in range(MAX_RETRIES + 1):
        prompt = build_prompt(ctx, refs, feedback)
        try:
            result = parse_json(llm(prompt))
            issues = validate(result, ctx, bank, embedder)
        except (ValueError, json.JSONDecodeError) as e:
            result, issues = {}, [f"Output was not valid JSON: {e}"]

        if not issues:
            break
        feedback = "\n".join(f"- {i}" for i in issues)
        print(f"[attempt {attempt + 1}] {len(issues)} issue(s), retrying...", file=sys.stderr)

    return {
        "role": ctx.role,
        "skills": ctx.skills,
        "status": "ready_for_review" if not issues else "needs_human_attention",
        "validation_issues": issues,
        "questions": result,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate intern interview questions.")
    ap.add_argument("--role", required=True)
    ap.add_argument("--jd", required=True, help="path to job description text file")
    ap.add_argument("--profile", required=True, help="path to intern profile text file")
    ap.add_argument("--bank", required=True, help="path to question bank JSON")
    ap.add_argument("--out", default="interview_set.json")
    ap.add_argument("--backend", choices=["anthropic", "llama"], default="anthropic")
    ap.add_argument("--dry-run", action="store_true", help="print prompt and exit")
    args = ap.parse_args()

    jd = open(args.jd, encoding="utf-8").read()
    profile = strip_pii(open(args.profile, encoding="utf-8").read())
    ctx = Context(role=args.role, jd_text=jd, profile_text=profile,
                  skills=extract_skills(jd))

    embedder = SentenceTransformer(EMBED_MODEL)
    bank = QuestionBank(args.bank, embedder)

    if args.dry_run:
        refs = bank.retrieve(f"{ctx.role}. Skills: {', '.join(ctx.skills)}")
        print(build_prompt(ctx, refs))
        return

    llm = anthropic_llm if args.backend == "anthropic" else local_llama_llm
    output = generate_interview_set(ctx, bank, embedder, llm)

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print(f"Saved {args.out} (status: {output['status']})")


if __name__ == "__main__":
    main()
